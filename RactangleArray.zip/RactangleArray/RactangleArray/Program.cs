﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RactangleArray
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,]MH = new string[2, 2]
            {
                {"Proffesor","Roy"},
                {"Berline","Tokiyo"}
            };


            foreach (string val1 in MH)
            {
                Console.WriteLine(val1);
            }
            Console.Read();
        }
    }
}
