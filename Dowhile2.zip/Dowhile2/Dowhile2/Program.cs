﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dowhile2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=1;
            do
            {
                do
                {
                    int j = 1;
                    Console.Write(j);
                    j++;

                }
                while (j <= i);
                i++;
            }
            while (i <= 5);
            Console.Read();
        }
     
    }
     
}
