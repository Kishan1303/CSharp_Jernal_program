﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StudMarkshit
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3, total, grade,avg;
            Console.Write("Enter first marks ");
            m1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second marks ");
            m2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third marks ");
            m3 = Convert.ToInt32(Console.ReadLine());

            total = m1 + m2 + m3;
            avg = total/3;
            Console.WriteLine("Total Marks "+total);
            Console.WriteLine("Total Avg "+avg);
            if(m1>=40 && m2>=40 && m3>=40)
            {
                 if (avg >= 70)
                {
                    Console.WriteLine("Grade is A:");
                  }
                 else if (avg >= 60)
                 {
                     Console.WriteLine("Grade is B:");
                  }
                  else if (avg >= 50)
                 {
                       Console.WriteLine("grae is C:");
                 }
                 else 
                  {
                    Console.WriteLine("Grade is D:");
                  }
            }
            else
            {
                Console.WriteLine("Fail");
            }
            
            Console.Read();
        }
    }
}
