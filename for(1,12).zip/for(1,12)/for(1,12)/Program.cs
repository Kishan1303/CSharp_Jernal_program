﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace for_1_12_
{
    class Program
    {
        static void Main(string[] args)
        {
      
        }
    }
}
