﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            object obj = a;
            int b = (int)obj;
            Console.WriteLine(b);
            Console.ReadLine();
        }
    }
}
