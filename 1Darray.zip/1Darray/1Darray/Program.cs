﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1Darray
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] kishan = { "Andy","Carlo","Sara","Victor" };
            foreach (string val in kishan)
            {
                Console.WriteLine(val);
            }
            Console.Read();
        }
         
    }
}
