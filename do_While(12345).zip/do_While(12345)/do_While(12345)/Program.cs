﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace do_While_12345_
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=1;
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i <= 5);
            Console.Read();
        }
    }
}
