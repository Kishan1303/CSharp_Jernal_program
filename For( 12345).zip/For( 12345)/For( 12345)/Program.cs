﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace For__12345_
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i<=5; i++)
            {
                Console.WriteLine(i);
                
            }
            Console.Read();
        }
    }
}
