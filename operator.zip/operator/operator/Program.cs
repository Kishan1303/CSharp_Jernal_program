﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @operator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a :");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter b :");
            int b = Convert.ToInt32(Console.ReadLine());

            //int c = Convert.ToInt32(Console.ReadLine());

            // arithmatic operator
           
            Console.WriteLine("Sum :"+(a+b));

            Console.WriteLine("Sub"+(a-b));

            Console.WriteLine("Div"+(a/b));

            Console.WriteLine("Mul"+(a*b));

          Console.WriteLine("Modu"+(a%b));

            // relitional operator

          if (a > b)
          { Console.WriteLine("A is Bigger than B"); }
          if(a<b)
          { Console.WriteLine("B is Bigger than A");}
          if(a<=b)
         { Console.WriteLine("B is Bigger or Equal to  than A");}
          if(a>=b)
          {Console.WriteLine("A is Bigger or Equal to B"); }
        if(a!=b)
        {Console.WriteLine("A is Not Equal to B");}
        if(a==b)
        {Console.WriteLine("A is Equal to b");}

        Console.Read();
        }
    }
}
